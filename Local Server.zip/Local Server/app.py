from flask import Flask, request, render_template, redirect, url_for, flash, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Configurations
UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///documents.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize database
db = SQLAlchemy(app)

# Document model
class Document(db.Model):
    id = db.Column(db.String(50), primary_key=True, unique=True)
    password_hash = db.Column(db.String(128), nullable=False)
    filename = db.Column(db.String(255), nullable=False)

# Ensure upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/", methods=["GET"])
def home():
    return render_template("upload.html")

@app.route("/upload", methods=["POST"])
def upload():
    document_id = request.form.get("document_id")
    password = request.form.get("password")
    file = request.files["file"]

    if not document_id or not password or not file:
        flash("All fields are required!")
        return redirect(url_for("home"))

    if Document.query.filter_by(id=document_id).first():
        flash("Document ID already exists. Choose a different one.")
        return redirect(url_for("home"))

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(file_path)

    new_document = Document(
        id=document_id,
        password_hash=generate_password_hash(password),
        filename=filename
    )
    db.session.add(new_document)
    db.session.commit()

    flash("Document uploaded successfully!")
    return redirect(url_for("home"))

@app.route("/retrieve", methods=["GET", "POST"])
def retrieve():
    if request.method == "GET":
        return render_template("retrieve.html")

    document_id = request.form.get("document_id")
    password = request.form.get("password")

    if not document_id or not password:
        flash("All fields are required!")
        return redirect(url_for("retrieve"))

    document = Document.query.filter_by(id=document_id).first()
    if not document or not check_password_hash(document.password_hash, password):
        flash("Invalid ID or password!")
        return redirect(url_for("retrieve"))

    return send_from_directory(app.config["UPLOAD_FOLDER"], document.filename, as_attachment=True)

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)